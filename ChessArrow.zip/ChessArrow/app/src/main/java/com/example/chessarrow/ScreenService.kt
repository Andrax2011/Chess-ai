package com.example.chessarrow

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.*
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.hypot

class ScreenService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("capture").apply { start() }
    private val work: Handler by lazy { Handler(thread.looper) }
    private val pool = Executors.newSingleThreadExecutor()
    private val reader = BoardReader()

    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var ir: ImageReader? = null
    @Volatile private var engine: Engine? = null

    private lateinit var av: ArrowView
    private lateinit var panel: LinearLayout
    private lateinit var info: TextView
    private var sw = 0
    private var sh = 0

    @Volatile private var learnNext = false
    @Volatile private var currentFen = ""
    private var lastTs = 0L
    private var pending: String? = null
    private var committed: String? = null
    private var lastPos: Array<CharArray>? = null
    private var turn = 'w'

    private val me: Char get() = if (av.white) 'w' else 'b'

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || proj != null) return START_NOT_STICKY
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startFg()
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val data = i.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        proj = mpm.getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, ui)
        setupCapture()
        setupOverlay()
        startEngine()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("c", "ChessArrow", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "c")
            .setContentTitle("ChessArrow работает")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun toast(t: String) { ui.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() } }

    private fun startEngine() {
        pool.execute {
            val f = File(applicationInfo.nativeLibraryDir, "libstockfish.so")
            if (!f.exists()) { toast("В сборке нет libstockfish.so"); return@execute }
            try { engine = Engine(f.absolutePath) } catch (e: Exception) { toast("Движок не запустился: ${e.message}") }
        }
    }

    // ---------- захват экрана ----------

    private fun setupCapture() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels
        ir = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        vd = proj!!.createVirtualDisplay(
            "cap", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir!!.surface, null, null
        )
        ir!!.setOnImageAvailableListener({ r -> onFrame(r) }, work)
    }

    private fun onFrame(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastTs < 250) return          // ~4 кадра в секунду хватает
            lastTs = now
            val p = img.planes[0]
            val bmp = Bitmap.createBitmap(p.rowStride / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(p.buffer)
            process(bmp)
            bmp.recycle()
        } finally {
            img.close()
        }
    }

    // ---------- логика ----------

    private val start = arrayOf("RNBQKBNR", "PPPPPPPP", "........", "........", "........", "........", "pppppppp", "rnbqkbnr")
    private fun isStart(p: Array<CharArray>) = p.indices.all { String(p[it]) == start[it] }

    /** Чей ход, по тому, что изменилось между двумя позициями. */
    private fun nextTurn(prev: Array<CharArray>?, pos: Array<CharArray>): Char {
        if (isStart(pos)) return 'w'
        if (prev == null) return me
        var n = 0; var mover = ' '
        for (r in 0..7) for (f in 0..7) if (prev[r][f] != pos[r][f]) {
            n++
            if (mover == ' ' && pos[r][f] != '.') mover = if (pos[r][f].isUpperCase()) 'w' else 'b'
        }
        if (n == 0) return turn
        if (n > 4 || mover == ' ') return me
        return if (mover == 'w') 'b' else 'w'
    }

    private fun process(bmp: Bitmap) {
        if (learnNext) {
            learnNext = false
            val ok = reader.learn(bmp, av.bl, av.bt, av.bs, av.white)
            if (ok) {
                lastPos = null; committed = null; pending = null; turn = 'w'
                ui.post { av.showFrame = false; av.move = null; av.invalidate(); info.text = "Выучил. Играй" }
            } else toast("Не вижу начальную расстановку: подгони рамку")
            return
        }
        val pos = reader.read(bmp, av.bl, av.bt, av.bs, av.white) ?: return
        val key = pos.joinToString("/") { String(it) }
        if (key != pending) { pending = key; return }      // ждём два одинаковых кадра подряд
        if (key == committed) return

        turn = nextTurn(lastPos, pos)
        committed = key; lastPos = pos
        ui.post { av.move = null; av.invalidate() }
        if (turn != me) { ui.post { info.text = "Ход соперника" }; return }

        val fen = BoardReader.fen(pos, turn) ?: return
        currentFen = fen
        ui.post { info.text = "Думаю…" }
        pool.execute {
            if (fen != currentFen) return@execute           // позиция уже устарела
            val e = engine ?: return@execute
            val mv = e.best(fen, 700)
            if (mv != null && fen == currentFen) ui.post { av.move = mv; av.invalidate(); info.text = mv }
        }
    }

    // ---------- оверлей ----------

    private fun btn(t: String, repeat: Boolean = false, a: () -> Unit): Button {
        val b = Button(this)
        b.text = t; b.isAllCaps = false; b.textSize = 14f
        b.minWidth = 0; b.minimumWidth = 0
        if (!repeat) { b.setOnClickListener { a() }; return b }
        val loop = object : Runnable { override fun run() { a(); b.postDelayed(this, 60) } }
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> loop.run()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> b.removeCallbacks(loop)
            }
            true
        }
        return b
    }

    private fun row(vararg v: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        v.forEach { l.addView(it) }
        return l
    }

    private fun setupOverlay() {
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        // FLAG_SECURE: надеемся, что наши окна не попадут в захват экрана (иначе стрелка портит распознавание)
        val secure = WindowManager.LayoutParams.FLAG_SECURE
        val nf = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

        av = ArrowView(this)
        av.bs = sw; av.bl = 0; av.bt = (sh - sw) / 3
        wm.addView(
            av,
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
                nf or secure or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
        )

        info = TextView(this)
        info.setTextColor(Color.WHITE); info.textSize = 15f; info.setPadding(16, 8, 16, 8)
        info.text = "Подгони рамку → «Учить»"

        val up = btn("▲", true) { av.bt -= 10; av.invalidate() }
        val down = btn("▼", true) { av.bt += 10; av.invalidate() }
        val plus = btn("+", true) { av.bs += 8; av.bl -= 4; av.invalidate() }
        val minus = btn("−", true) { av.bs -= 8; av.bl += 4; av.invalidate() }
        val flip = btn("Разворот") { av.white = !av.white; toast(if (av.white) "Белые внизу" else "Чёрные внизу") }
        val learn = btn("Учить") { learnNext = true }
        val frame = btn("Рамка") { av.showFrame = !av.showFrame; av.invalidate() }
        val close = btn("✕") { stopSelf() }

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setBackgroundColor(0xCC000000.toInt())
        panel.addView(info)
        panel.addView(row(up, down, plus, minus))
        panel.addView(row(flip, learn, frame, close))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, nf or secure, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        wm.addView(panel, lp)
    }

    override fun onDestroy() {
        try { vd?.release() } catch (_: Exception) {}
        try { ir?.close() } catch (_: Exception) {}
        val p = proj; proj = null
        try { p?.stop() } catch (_: Exception) {}
        engine?.close()
        pool.shutdownNow()
        thread.quitSafely()
        if (::av.isInitialized) try { wm.removeView(av) } catch (_: Exception) {}
        if (::panel.isInitialized) try { wm.removeView(panel) } catch (_: Exception) {}
        super.onDestroy()
    }
}

/** Прозрачный слой на весь экран: рисует рамку доски и стрелку хода. Клики пропускает. */
class ArrowView(c: Context) : View(c) {
    @Volatile var bl = 0
    @Volatile var bt = 0
    @Volatile var bs = 0
    @Volatile var white = true
    @Volatile var showFrame = true
    @Volatile var move: String? = null

    private val frame = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.RED }
    private val grid = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 1f; color = 0x88FF0000.toInt() }
    private val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = 0xCC00C853.toInt()
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC00C853.toInt() }

    override fun onDraw(cv: Canvas) {
        // окно может начинаться не в (0,0) экрана (вырез, статус-бар), поэтому сдвигаем систему координат
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        cv.translate(-loc[0].toFloat(), -loc[1].toFloat())

        val s = bs / 8f
        val l = bl.toFloat(); val t = bt.toFloat()
        if (showFrame) {
            cv.drawRect(l, t, l + bs, t + bs, frame)
            for (i in 1..7) {
                cv.drawLine(l + i * s, t, l + i * s, t + bs, grid)
                cv.drawLine(l, t + i * s, l + bs, t + i * s, grid)
            }
        }

        val m = move ?: return
        if (m.length < 4) return
        fun center(sq: String): PointF {
            val f = sq[0] - 'a'; val r = sq[1] - '1'
            val col = if (white) f else 7 - f
            val row = if (white) 7 - r else r
            return PointF(l + (col + 0.5f) * s, t + (row + 0.5f) * s)
        }
        val a = center(m.substring(0, 2)); val b = center(m.substring(2, 4))
        val dx = b.x - a.x; val dy = b.y - a.y
        val len = hypot(dx, dy)
        if (len < 1f) return
        val ux = dx / len; val uy = dy / len
        val hl = s * 0.45f; val hw = s * 0.3f
        arrow.strokeWidth = s * 0.16f
        val tx = b.x - ux * hl; val ty = b.y - uy * hl
        cv.drawLine(a.x, a.y, tx, ty, arrow)
        val p = Path()
        p.moveTo(b.x, b.y)
        p.lineTo(tx - uy * hw, ty + ux * hw)
        p.lineTo(tx + uy * hw, ty - ux * hw)
        p.close()
        cv.drawPath(p, head)
    }
}
