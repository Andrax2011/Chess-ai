package com.example.chessarrow

/** Обёртка над Stockfish: запускает бинарник как процесс и говорит с ним по протоколу UCI. */
class Engine(path: String) {
    private val p = ProcessBuilder(path).redirectErrorStream(true).start()
    private val w = p.outputStream.bufferedWriter()
    private val r = p.inputStream.bufferedReader()

    init {
        send("uci"); readUntil("uciok")
        send("setoption name Threads value ${maxOf(1, Runtime.getRuntime().availableProcessors() / 2)}")
        send("setoption name Hash value 64")
        send("isready"); readUntil("readyok")
    }

    private fun send(s: String) { w.write(s); w.write("\n"); w.flush() }

    private fun readUntil(prefix: String): String? {
        while (true) {
            val l = r.readLine() ?: return null
            if (l.startsWith(prefix)) return l
        }
    }

    /** Лучший ход в формате "e2e4" (или "e7e8q"); null, если ходов нет. */
    @Synchronized
    fun best(fen: String, ms: Int): String? {
        send("position fen $fen")
        send("go movetime $ms")
        val l = readUntil("bestmove") ?: return null
        val m = l.split(" ").getOrNull(1) ?: return null
        return if (m == "(none)" || m.length < 4) null else m
    }

    fun close() {
        try { send("quit") } catch (_: Exception) {}
        p.destroy()
    }
}
