package com.example.chessarrow

import android.graphics.Bitmap
import kotlin.math.abs

/**
 * Читает позицию с картинки доски. Никакого обучения заранее: шаблоны фигур
 * "снимаются" с экрана, когда на нём начальная расстановка (learn).
 * Фон клетки вычитается, поэтому светлые и тёмные клетки не мешают.
 */
class BoardReader {
    private val N = 16
    private class Tpl(val ch: Char, val f: IntArray)

    private var tpls = listOf<Tpl>()
    val ready get() = tpls.isNotEmpty()

    private fun d3(a: IntArray, b: IntArray) = abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])

    private fun avg(px: IntArray, st: Int, x0: Int, y0: Int, w: Int, h: Int = w): IntArray {
        var r = 0; var g = 0; var b = 0; var n = 0
        for (y in y0 until y0 + h) for (x in x0 until x0 + w) {
            val p = px[y * st + x]
            r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; n++
        }
        if (n == 0) return intArrayOf(0, 0, 0)
        return intArrayOf(r / n, g / n, b / n)
    }

    /** Признаки одной клетки: сетка N*N, -1 = фон, иначе цвет RGB. */
    private fun feat(b: Bitmap, sx: Int, sy: Int, s: Int): IntArray {
        val px = IntArray(s * s)
        b.getPixels(px, 0, s, sx, sy, s, s)
        val k = maxOf(2, s / 12)
        val cs = listOf(avg(px, s, 0, 0, k), avg(px, s, s - k, 0, k), avg(px, s, 0, s - k, k), avg(px, s, s - k, s - k, k))
        var bg = cs[0]; var bestSum = Int.MAX_VALUE
        for (a in cs) {
            var sum = 0
            for (o in cs) sum += d3(a, o)
            if (sum < bestSum) { bestSum = sum; bg = a }
        }
        val ins = s * 8 / 100
        val area = s - 2 * ins
        val out = IntArray(N * N)
        for (cy in 0 until N) for (cx in 0 until N) {
            val x0 = ins + cx * area / N; val x1 = ins + (cx + 1) * area / N
            val y0 = ins + cy * area / N; val y1 = ins + (cy + 1) * area / N
            val c = avg(px, s, x0, y0, maxOf(1, x1 - x0), maxOf(1, y1 - y0))
            out[cy * N + cx] = if (d3(c, bg) < 48) -1 else (c[0] shl 16) or (c[1] shl 8) or c[2]
        }
        return out
    }

    private fun fg(f: IntArray) = f.count { it != -1 }
    private fun isEmpty(f: IntArray) = fg(f) < N * N * 18 / 100

    private fun dist(a: IntArray, b: IntArray): Int {
        var d = 0
        for (i in a.indices) {
            val x = a[i]; val y = b[i]
            d += if (x == -1 && y == -1) 0
            else if (x == -1 || y == -1) 150
            else (abs(((x shr 16) and 255) - ((y shr 16) and 255)) +
                    abs(((x shr 8) and 255) - ((y shr 8) and 255)) +
                    abs((x and 255) - (y and 255))) / 3
        }
        return d
    }

    private fun inside(b: Bitmap, l: Int, t: Int, size: Int): Boolean {
        val s = size / 8
        return s >= 16 && l >= 0 && t >= 0 && l + s * 8 <= b.width && t + s * 8 <= b.height
    }

    /** Запомнить внешний вид фигур. Нужна начальная расстановка на экране. */
    fun learn(b: Bitmap, left: Int, top: Int, size: Int, whiteBottom: Boolean): Boolean {
        if (!inside(b, left, top, size)) return false
        val s = size / 8
        val back = "rnbqkbnr"
        val list = ArrayList<Tpl>()
        for (rank in listOf(0, 1, 6, 7)) for (file in 0..7) {
            val ch = when (rank) {
                0 -> back[file].uppercaseChar()
                1 -> 'P'
                6 -> 'p'
                else -> back[file]
            }
            val col = if (whiteBottom) file else 7 - file
            val row = if (whiteBottom) 7 - rank else rank
            list += Tpl(ch, feat(b, left + col * s, top + row * s, s))
        }
        if (list.any { isEmpty(it.f) }) return false
        tpls = list
        return true
    }

    /** Позиция как pos[rank 0..7][file 0..7]: 'P' белая пешка, 'p' чёрная, '.' пусто. */
    fun read(b: Bitmap, left: Int, top: Int, size: Int, whiteBottom: Boolean): Array<CharArray>? {
        if (!ready || !inside(b, left, top, size)) return null
        val s = size / 8
        val pos = Array(8) { CharArray(8) { '.' } }
        for (row in 0..7) for (col in 0..7) {
            val f = feat(b, left + col * s, top + row * s, s)
            var ch = '.'
            if (!isEmpty(f)) {
                var best = Int.MAX_VALUE
                for (t in tpls) { val d = dist(f, t.f); if (d < best) { best = d; ch = t.ch } }
            }
            val file = if (whiteBottom) col else 7 - col
            val rank = if (whiteBottom) 7 - row else row
            pos[rank][file] = ch
        }
        return pos
    }

    companion object {
        /** FEN для движка. Рокировки определяются по месту короля/ладей, взятие на проходе не учитывается. */
        fun fen(p: Array<CharArray>, turn: Char): String? {
            var wk = 0; var bk = 0
            val sb = StringBuilder()
            for (rank in 7 downTo 0) {
                var e = 0
                for (file in 0..7) {
                    val c = p[rank][file]
                    if (c == '.') e++ else {
                        if (e > 0) { sb.append(e); e = 0 }
                        sb.append(c)
                        if (c == 'K') wk++
                        if (c == 'k') bk++
                    }
                }
                if (e > 0) sb.append(e)
                if (rank > 0) sb.append('/')
            }
            if (wk != 1 || bk != 1) return null
            val c = StringBuilder()
            if (p[0][4] == 'K' && p[0][7] == 'R') c.append('K')
            if (p[0][4] == 'K' && p[0][0] == 'R') c.append('Q')
            if (p[7][4] == 'k' && p[7][7] == 'r') c.append('k')
            if (p[7][4] == 'k' && p[7][0] == 'r') c.append('q')
            val castle = if (c.isEmpty()) "-" else c.toString()
            return "$sb $turn $castle - 0 1"
        }
    }
}
